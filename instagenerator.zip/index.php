<?php
include("gpt.php");
include("watermark.php");



// echo $content;

$fileNames = array("00.jpg", "01.jpg", "02.jpg", "03.jpg", "04.jpg", "05.jpg");


for ($i=0; $i<=10; $i++){
    $content = generate_article('Create an interesting Instagram post less than 50 words long without any emojis or hashtags in a new paragraph. The topic of the post should be randomly chosen from the following options: Wellness, Fitness, Health, Mindfulness, Self-care, Yoga, Meditation, Minimalism, Productivity, Motivation, Inspiration, Entrepreneurship, Online Business, Leadership, Mindset, Mental Health, Business Psychology, or Success. return only post content do not return any suggetions');
    $input = $fileNames[array_rand($fileNames)];
    $output = 'outputs/'.uniqid().'.jpg';
    addWatermark($input, $content, $output);
    echo '<img src="'.$output.'" width="540px" height="540px"> <br>';
    echo $i;
}




?>

